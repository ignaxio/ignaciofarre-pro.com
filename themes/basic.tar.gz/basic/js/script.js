/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//$(document).ready(function () {
//  var imagen = $('article img');
//  console.log(imagen);
//});

//(function ($, Drupal) {
//
//  // It's best practice to use strict mode, can help avoid some browser issues.
//  'use strict';
//
//  // Generally you always want to use behaviors, remember to depend on Drupal js.
////  Drupal.behaviors.name = {
////    // Called on document ready and when no elements is added to the page.
////    attach: function (context, settings) {
////      $(".selector", context)...
////    }
////  }
//
//  // Sometimes you just want to do something when DOM is ready.
//  $(document).ready(function() {
//    $('article img').addClass('img-responsive');
//    
//    var imagen = $('article img');
//  console.log(imagen);
//  });
//
//})(window.jQuery, window.Drupal);